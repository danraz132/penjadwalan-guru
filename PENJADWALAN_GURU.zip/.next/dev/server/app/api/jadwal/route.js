var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/jadwal/route.js")
R.c("server/chunks/node_modules_next_c7d5a404._.js")
R.c("server/chunks/[root-of-the-server]__4a743d01._.js")
R.c("server/chunks/_next-internal_server_app_api_jadwal_route_actions_36f4ec9c.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/jadwal/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/jadwal/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
