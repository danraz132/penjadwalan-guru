module.exports = [
"[project]/.next-internal/server/app/api/guru/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_guru_route_actions_f1ec8fcb.js.map