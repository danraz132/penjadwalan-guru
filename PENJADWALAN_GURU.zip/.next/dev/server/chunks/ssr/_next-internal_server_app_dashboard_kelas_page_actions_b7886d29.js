module.exports = [
"[project]/.next-internal/server/app/dashboard/kelas/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_kelas_page_actions_b7886d29.js.map