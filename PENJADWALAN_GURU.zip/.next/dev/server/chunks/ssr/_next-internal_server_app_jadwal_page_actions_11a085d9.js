module.exports = [
"[project]/.next-internal/server/app/jadwal/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_jadwal_page_actions_11a085d9.js.map