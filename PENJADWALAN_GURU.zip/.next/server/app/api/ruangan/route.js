var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/ruangan/route.js")
R.c("server/chunks/[root-of-the-server]__a3a1baf6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_ruangan_route_actions_1d75ceea.js")
R.m(41517)
module.exports=R.m(41517).exports
