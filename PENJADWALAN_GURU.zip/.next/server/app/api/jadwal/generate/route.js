var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/jadwal/generate/route.js")
R.c("server/chunks/[root-of-the-server]__96794348._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_jadwal_generate_route_actions_424464bd.js")
R.m(80942)
module.exports=R.m(80942).exports
