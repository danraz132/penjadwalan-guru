var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/guru/[id]/mapel/route.js")
R.c("server/chunks/[root-of-the-server]__64e13783._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_guru_[id]_mapel_route_actions_e4986cf4.js")
R.m(94312)
module.exports=R.m(94312).exports
