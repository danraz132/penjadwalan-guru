var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/guru/route.js")
R.c("server/chunks/[root-of-the-server]__690a446b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_guru_route_actions_f1ec8fcb.js")
R.m(52733)
module.exports=R.m(52733).exports
