var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/kelas/route.js")
R.c("server/chunks/[root-of-the-server]__de7e1981._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_kelas_route_actions_d553e11f.js")
R.m(82896)
module.exports=R.m(82896).exports
