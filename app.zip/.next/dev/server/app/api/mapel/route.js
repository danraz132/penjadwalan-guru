var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/mapel/route.js")
R.c("server/chunks/node_modules_next_dd19299a._.js")
R.c("server/chunks/[root-of-the-server]__ec91e361._.js")
R.c("server/chunks/_next-internal_server_app_api_mapel_route_actions_68d68562.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/mapel/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/mapel/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
