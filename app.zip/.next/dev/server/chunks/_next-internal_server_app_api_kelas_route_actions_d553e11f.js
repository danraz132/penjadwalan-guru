module.exports = [
"[project]/.next-internal/server/app/api/kelas/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_kelas_route_actions_d553e11f.js.map