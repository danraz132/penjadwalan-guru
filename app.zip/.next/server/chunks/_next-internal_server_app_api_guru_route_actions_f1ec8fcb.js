module.exports=[11264,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_guru_route_actions_f1ec8fcb.js.map