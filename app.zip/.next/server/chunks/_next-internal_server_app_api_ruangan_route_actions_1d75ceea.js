module.exports=[84089,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ruangan_route_actions_1d75ceea.js.map