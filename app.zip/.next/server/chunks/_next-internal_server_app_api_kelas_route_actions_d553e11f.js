module.exports=[8360,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_kelas_route_actions_d553e11f.js.map