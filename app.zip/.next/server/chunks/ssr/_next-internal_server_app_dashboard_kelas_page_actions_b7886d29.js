module.exports=[17453,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_kelas_page_actions_b7886d29.js.map