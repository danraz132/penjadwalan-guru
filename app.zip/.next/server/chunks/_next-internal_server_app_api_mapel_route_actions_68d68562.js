module.exports=[14573,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mapel_route_actions_68d68562.js.map