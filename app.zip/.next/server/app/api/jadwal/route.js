var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/jadwal/route.js")
R.c("server/chunks/[root-of-the-server]__bb871a19._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_jadwal_route_actions_36f4ec9c.js")
R.m(87906)
module.exports=R.m(87906).exports
