var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/ruangan/route.js")
R.c("server/chunks/[root-of-the-server]__76f11bc2._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_ruangan_route_actions_1d75ceea.js")
R.m(41517)
module.exports=R.m(41517).exports
