var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/kelas/route.js")
R.c("server/chunks/[root-of-the-server]__d87bee82._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_kelas_route_actions_d553e11f.js")
R.m(82896)
module.exports=R.m(82896).exports
