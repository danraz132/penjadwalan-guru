var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/guru/route.js")
R.c("server/chunks/[root-of-the-server]__4758dc8d._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_guru_route_actions_f1ec8fcb.js")
R.m(52733)
module.exports=R.m(52733).exports
